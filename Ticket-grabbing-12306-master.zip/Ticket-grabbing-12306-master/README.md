### Ticket-grabbing-12306是一款基于python3开发的一款12306抢票软件。

### 版本规划：

	1. 12月末发布源码版本，并发布使用说明
 	2. 1月末发布图形化版本,（只适用于windows用户）
	3. 长期维护两个版本，你的start，是我们更新的动力！

### 软件正在开发中，尽请期待~



### Edge驱动下载地址
https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/

### 谷歌驱动下载地址

