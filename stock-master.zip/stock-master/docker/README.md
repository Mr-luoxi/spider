
# python 基础镜像

基础镜像升级到 2020年7月的版本

保证运行的最少基础环境，基础环境使用python3.6的版本。安装了超级多的lib库。非常的好用。

mysqlclient
sqlalchemy
requests
numpy
tushare
tornado torndb
bokeh
stockstats
ta-lib
jupyter
sklearn

# 